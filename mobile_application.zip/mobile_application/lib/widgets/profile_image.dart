import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';


class ProfileImage extends StatelessWidget {
  final File? imageFile;
  final Uint8List? imageBytes;
  final VoidCallback onImagePick;

  const ProfileImage({
    Key? key,
    this.imageFile,
    this.imageBytes,
    required this.onImagePick,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    ImageProvider fallback =
        const NetworkImage('https://picsum.photos/250?image=9');

    ImageProvider provider;
    if (imageFile != null) {
      provider = FileImage(imageFile!);
    } else if (imageBytes != null) {
      provider = MemoryImage(imageBytes!);
    } else {
      provider = fallback;
    }

    final bool hasCustomImage = imageFile != null || imageBytes != null;

    return GestureDetector(
      onTap: onImagePick,
      child: CircleAvatar(
        radius: 50,
        backgroundImage: provider,
        child: !hasCustomImage
            ? const Icon(
                Icons.camera_alt,
                size: 50,
                color: Colors.white,
              )
            : null,
      ),
    );
  }
}
